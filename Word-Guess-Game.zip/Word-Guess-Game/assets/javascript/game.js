var animals = ["rhinoceros", "pangolin", "wildebeest", "ostrich", "tapir", "salamander", "platypus", "wombat", "blue dragon", "mantis shrimp"];

var randomAnimal = "";
var wordLetters = [];
var blanks = 0;
var blanksAndCorrect = [];
var wrongGuess = [];
var wins = 0;
var guessesRemaining = 9;
var userGuess = "";
var userGuessed = [];
var answerArray = [];
var currentAnimal = "";
var remainingLetters = "";
var winLine = 0;
var lossLine = 0;
var losses = "";


//Start Function

function Game() {
    randomAnimal = animals[Math.floor(Math.random() * animals.length)];
    console.log (randomAnimal)

  //splits the individual animal away from the array and stores new animal array as letters
    wordLetters = randomAnimal.split("");

  //stores word length in blanks
    blanks = wordLetters.length;

  //loop to generate "_" for every animal array
    for (var i = 0; i < blanks; i++) {
        blanksAndCorrect.push("_");
    if (userGuess == i); 
    }


  //shows dashes in html
    document.getElementById("currentAnimal").innerHTML = "  " + blanksAndCorrect.join("  "); 
}

function reset() {
    guessesRemaining = 9;
    wrongGuess = [];
    blanksAndCorrect = [];
    Game()
  }

//detects key press and released
  document.onkeyup = function(event) {

    
    // Determines which key was pressed.
    var userGuess = event.key.toLowerCase();
    userGuess.textContent = "Wins: " + wins;
    wrongGuess.textContent = "Losses: " + losses;
    guessesRemaining.textContent = "Guesses Left: " + guessesRemaining;
    userGuessed.textContent = "Guesses So Far: " + userGuessed;

if (userGuess.length !==1) {
    alert("Enter a single letter.");
  } else 
  for (var j = 0; j <wordLetters.length; j++); {
    if (wordLetters[j] == userGuess); {
      (answerArray[j] ==  userGuess); (remainingLetters--);  

      document.getElementById('wins').innerHTML = "Wins: " + wins;
      document.getElementById('losses').innerHTML = "losses: " + losses;
      document.getElementById('userGuesses').innerHTML = "Guesses left: " + guesses;





console.log (wordLetters)
    }
  }
}

 //Call Game Function
Game();